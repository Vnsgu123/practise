package com.example.myapplication


class Contactmodel(val image:Int , val name:String , val number:String) {

}