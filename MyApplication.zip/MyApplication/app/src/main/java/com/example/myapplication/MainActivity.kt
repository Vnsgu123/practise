package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.constraintlayout.helper.widget.Carousel.Adapter
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var rec = findViewById<RecyclerView>(R.id.recyclerContact)
        rec.layoutManager=LinearLayoutManager(this)

        val data = ArrayList<Contactmodel>()

        for (i in 1..20)
        {
            data.add(Contactmodel(R.drawable.contact,"ish","6747288228"))
        }


        val adapter = RecyclerContact(data)

        rec.adapter=adapter

    }
}