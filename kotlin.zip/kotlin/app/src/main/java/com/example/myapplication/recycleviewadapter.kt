package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.customer

class recyAdapter(private val customerlist:List<customer>) : RecyclerView.Adapter<recyAdapter.viewholder>() {
    class viewholder(custview : View) :
        RecyclerView.ViewHolder(custview)
    {
        val
                txtid:TextView=custview.findViewById(R.id.e1)
        val
                txtname:TextView=custview.findViewById(R.id.e2)
        val
                txtano:TextView=custview.findViewById(R.id.e3)
    }
    override fun onCreateViewHolder(parent: ViewGroup,viewType: Int): viewholder {
        val view= LayoutInflater.from(parent.context).inflate(R.layout.listitem, parent, false)
            return viewholder(view)
    }
    override fun getItemCount(): Int
    {
        return customerlist.count()
    }
    override fun onBindViewHolder(holder: viewholder, position: Int) {
        val custlistmodel=customerlist[position]
        holder.txtid.text=custlistmodel.id.toString()
        holder.txtname.text=custlistmodel.name.toString()

        holder.txtano.text=custlistmodel.acc_no.toString()
    }
}

//import android.view.View
//import android.widget.TextView
//import androidx.recyclerview.widget.RecyclerView
//
//class recycleviewadapter: RecyclerView.Adapter<RecyclerView.ViewHolder>() {
//    class ViewHolder(custview:View):RecyclerView.ViewHolder(custview)
//    {
//        val txtid:TextView = custview.findViewById(R.id.)
//
//
//    }
//}